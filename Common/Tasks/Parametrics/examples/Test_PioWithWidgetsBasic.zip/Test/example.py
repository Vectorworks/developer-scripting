#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Author:	_c_ for the German VS forum
# Date:		27.03.2021
# Version:	1.0 -- (c) 2021 _c_
#

# ---- IMPORTS ----

import vs

# ---- CONSTANTS ----

# parameter index in the plug-in editor
cP___div0 = 1 
cP___div1 = 5 
cP___div2 = 10

# arbitrary parameter index just large enough not to interfere with other things
cBut_Test = 1000

kObjOnInitXProperties = 5
kObjOnWidgetPrep = 41
kObjOnObjectUIButtonHit  = 35
kObjXPropHasUIOverride = 8
kParametricRecalculate = 3
kObjectEventHandled = -8

# widget types
kWidgetGroupMode = 81
kWidgetGroupAutomatic = 2
kWidgetButton = 12
kWidgetSeparator = 100

gPio_N = ''
gPio_H, gPioRec_H, gWall_H = vs.Handle(), vs.Handle(), vs.Handle()


# ---- METHODS ----


# _c_ ***********************************************
# GetLocalizedPluginParameter as function returning only a string
def O_GetLocParmName(pioRecName, univParmName):
	(boo, locParmName) = vs.GetLocalizedPluginParameter(pioRecName, univParmName)
	return locParmName
	
# --------------------------------------------------
def main():
	gDX = vs.Pwidth
	gDY = vs.Pdepth
	gDZ = vs.Pheigth
	
	vs.Rect(-gDX/2, -gDY/2, gDX/2, gDY/2)
	obj2D = vs.LNewObj
	
	vs.SetParameterVisibility(gPio_H, 'ControlPoint01X', vs.PshowLabel)
	vs.SetParameterVisibility(gPio_H, 'ControlPoint01Y', vs.PshowLabel)
	vs.SetCntrlPtVis(gPio_H, 1, vs.PshowLabel)
	
	t = vs.Plabel
	if vs.PshowLabel and (vs.Len(t) > 0):
		vs.MoveTo(vs.PControlPoint01X, vs.PControlPoint01Y)
		vs.CreateText(t)
		
	if gDZ > 0:
		vs.BeginXtrd(0, gDZ)
		vs.Rect(-gDX/2, -gDY/2, gDX/2, gDY/2)
		vs.EndXtrd()
	
	vs.SetObjectVariableBoolean(gPio_H, 800, True) 
	# set to respond to text commands such as font, size etc.
	

# --------------------------------------------------
# runs on button click
def ScriptWithSomething():
	vs.AlrtDialog('Let me do something!')
				
	
# --------------------------------------------------
def execute():
	global gPio_N, gPio_H, gPioRec_H, gWall_H
	empty = 0

	(ok, gPio_N, gPio_H, gPioRec_H, gWall_H) = vs.GetCustomObjectInfo()
	(theEvent, theButton) = vs.vsoGetEventInfo(  )
	
	if theEvent == kObjOnInitXProperties:
		ok = vs.SetObjPropVS( kObjXPropHasUIOverride, True )
		ok = vs.SetObjPropCharVS( kWidgetGroupMode, vs.Chr(kWidgetGroupAutomatic), True ) # add widget groups
		
		ok = vs.vsoInsertAllParams()
		ok = vs.vsoAppendWidget( kWidgetButton, cBut_Test, 'Test Button', empty )

		ok = vs.vsoInsertWidget( cP___div0 -1, kWidgetSeparator, cP___div0, O_GetLocParmName(gPio_N, '__div0'), empty);
		ok = vs.vsoInsertWidget( cP___div1 -1, kWidgetSeparator, cP___div1, O_GetLocParmName(gPio_N, '__div1'), empty);
		ok = vs.vsoInsertWidget( cP___div2 -1, kWidgetSeparator, cP___div2, O_GetLocParmName(gPio_N, '__div2'), empty);
		
		titles = [cP___div0, cP___div1, cP___div2]
		# mind the indexes, they are set up as constants
		
		for i in range(vs.NumFields(gPioRec_H) +1):
			if (i in titles): 
				vs.vsoWidgetSetIndLvl(i, 0)
			else:
				vs.vsoWidgetSetIndLvl(i, 1)
		
	elif theEvent == kParametricRecalculate:
		main()
					
	elif theEvent == kObjOnWidgetPrep:
		vs.vsoSetEventResult( kObjectEventHandled )
	
	elif theEvent == kObjOnObjectUIButtonHit:
		if theButton == cBut_Test:
			ScriptWithSomething()
	
